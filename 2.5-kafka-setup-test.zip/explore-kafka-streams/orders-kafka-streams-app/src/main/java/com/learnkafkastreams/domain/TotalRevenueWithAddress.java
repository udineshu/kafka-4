package com.learnkafkastreams.domain;

public record TotalRevenueWithAddress(TotalRevenue totalRevenue,
                                      Store store) {
}
