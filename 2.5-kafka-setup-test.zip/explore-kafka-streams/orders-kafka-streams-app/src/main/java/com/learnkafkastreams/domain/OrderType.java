package com.learnkafkastreams.domain;

public enum OrderType {
    GENERAL,
    RESTAURANT
}
