package com.learnkafkastreams.topology;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OrdersTopology {
    public static final String ORDERS = "orders";
    public static final String STORES = "stores";
}
